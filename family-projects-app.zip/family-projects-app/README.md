# Family Projects — Android & iOS App Project

This is a Capacitor project that wraps a "Family Projects" board app as a
real native app for both Android and iOS, using one shared codebase
(`www/index.html`).

**What the app does:** anyone in the family can post a project (e.g. "Clean
out the garage"), assign it to a family member, give it a due date, and move
it through To do → In progress → Done. Everything is stored locally on each
person's phone (no shared backend/account needed to get started).

The app icon is currently a placeholder carried over from an earlier
project — see the "Changing the icon" section below to swap it for your own.

---

## What's inside

```
doz-app/
├── www/index.html        ← your POS app (the actual app content)
├── android/               ← full native Android Studio project
├── ios/                   ← full native Xcode project
├── capacitor.config.json  ← app id, name, config
└── package.json
```

---

## Building the Android app (.apk / .aab)

**Requirements:** [Android Studio](https://developer.android.com/studio) (free, Windows/Mac/Linux)

1. Unzip this project anywhere on your computer.
2. Open **Android Studio** → "Open" → select the `doz-app/android` folder.
3. Let Gradle sync finish (first time can take a few minutes).
4. To test on your phone: plug in your Android phone (USB debugging enabled) → press ▶ Run.
5. To get an installable file:
   - **Build → Generate Signed Bundle / APK**
   - Choose **APK** for direct install, or **AAB** for Google Play Store upload.
   - You'll need to create a signing key the first time (Android Studio walks you through it).
6. The resulting `.apk` can be installed directly on any Android phone (enable "Install unknown apps" for your file manager/browser).

---

## Building the iOS app (.ipa)

**Requirements:** A Mac with **Xcode** installed (free from the Mac App Store), and an Apple ID (free tier lets you install on your own device for 7 days; a paid **Apple Developer account, $99/year**, is required for App Store submission or longer-lived installs).

1. Copy this project to your Mac.
2. Open Terminal, navigate to `doz-app/ios/App`, run:
   ```
   pod install
   ```
   (This requires [CocoaPods](https://cocoapods.org): `sudo gem install cocoapods` if you don't have it.)
3. Open `App.xcworkspace` (not `.xcodeproj`) in Xcode.
4. In the project settings, under **Signing & Capabilities**, choose your Apple ID team.
5. Plug in your iPhone → select it as the run target → press ▶ Run to install directly on your phone.
6. For distribution: **Product → Archive**, then use Xcode's Organizer to export an `.ipa` or upload to App Store Connect / TestFlight.

---

## Updating the app later

If you change `www/index.html` (e.g. add features, change prices/branding), re-sync both native projects with:

```
npx cap sync
```

This copies your updated HTML into both the Android and iOS projects. Then just rebuild in Android Studio / Xcode.

---

## Notes

- The app works fully offline — it uses `localStorage`, sandboxed inside the app's own storage on each device.
- **Important:** each phone keeps its own local list of projects. If your family installs this on separate phones, a project posted on one phone won't show up on another — everyone needs to use the same device, or you'd need a shared backend/database (a bigger project) for real syncing across phones.
- The app name is set to "Family Projects" and the package ID is `com.family.projects` — change this in `capacitor.config.json` (and the matching Android/iOS project files) and re-run `npx cap sync` if you want a different name or bundle identifier before publishing to app stores.

## Changing the icon

Replace `resources/icon.png` (1024x1024 recommended) and `resources/splash.png`,
then regenerate the native icon/splash files. The easiest way: install the
`@capacitor/assets` tool —

```
npm install @capacitor/assets --save-dev
npx capacitor-assets generate
```

— then re-open the project in Android Studio / Xcode.

## Publishing to Google Play

Building the AAB (see above) only gets you an installable file. To actually
see it on the Play Store, you also need, separately:
1. A Google Play Console developer account (Google account + one-time $25 fee + identity verification)
2. To create an app listing in the Play Console and upload the signed AAB
3. To fill out the store listing (screenshots, description, content rating, privacy policy)

This part has to be done by you, under your own Google account.
