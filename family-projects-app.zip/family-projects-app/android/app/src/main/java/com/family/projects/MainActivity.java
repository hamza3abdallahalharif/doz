package com.family.projects;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
